
function y=nanstd(x)

%calculate a std of a matrix w/ nan's in it
[M,N]=size(x);

if M==1 | N==1

   ind = find(isnan(x)==0);
   if ~isempty(ind)
      y=std(x(ind));
   else
      y=nan;
   end

elseif M>1 & N>1

for i=1:N

   for i=1:N
      ind = find(isnan(x(:,i))==0);
      if ~isempty(ind)
         y(i)=std(x(ind,i));
      else
         y(i)=nan;
      end
   end;


end;

end;

%% Updated this routine to check for an empty array before taking the std
%% of it.  Previously nanstd(x) if x is all nans produced an error message.
%% Below is the old version.
%% Helen - 7/3/02

%function y=nanstd(x)
%
%%calculate a std of a matrix w/ nan's in it
%[M,N]=size(x);
%
%if M==1 | N==1
%
%y=std(x(find(isnan(x)==0)));
%
%elseif M>1 & N>1
%
%for i=1:N
%
%y(i)=std(x(find(isnan(x(:,i))==0),i));
%
%end;
%
%end;
