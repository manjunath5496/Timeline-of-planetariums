
function y=nanmean(x)

%calculate a mean of a matrix w/ nan's in it
[M,N]=size(x);

if M==1 | N==1

   ind = find(isnan(x)==0);
   if ~isempty(ind)
      y=mean(x(ind));
   else
      y=nan;
   end

elseif M>1 & N>1

   for i=1:N
      ind = find(isnan(x(:,i))==0);
      if ~isempty(ind)
         y(i)=mean(x(ind,i));
      else
         y(i)=nan;
      end
   end;

end;

%% Updated this routine to check for an empty array before taking the mean
%% of it.  Previously nanmean(x) if x is all nans produced an error message.
%% Below is the old version.
%% Helen - 7/3/02


%function y=nanmean(x)
%
%%calculate a mean of a matrix w/ nan's in it
%[M,N]=size(x);
%
%if M==1 | N==1
%
%y=mean(x(find(isnan(x)==0)));
%
%elseif M>1 & N>1
%
%for i=1:N
%
%y(i)=mean(x(find(isnan(x(:,i))==0),i));
%
%end;
%
%end;
