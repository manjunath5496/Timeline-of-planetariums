function y=nanmax(x)

%calculate a max of a matrix w/ nan's in it
[M,N]=size(x);

if M==1 | N==1

notnan = find(~isnan(x));
y=max(x(notnan));

elseif M>1 & N>1

for i=1:N

notnan = find(~isnan(x(:,i)));
if isempty(notnan)
   y(i)=nan;
else
   y(i)=max(x(notnan,i));
end

end;

end;

% notnan part added by Helen 30 April 2002 because nanmax crashed when
% one of the columns of x was all nans.
