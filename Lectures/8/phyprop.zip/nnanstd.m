function y=nanstd(x)
% fix to handle all nan's - jadb 11/21/99
%calculate a std of a matrix w/ nan's in it
%
[M,N]=size(x);

if M==1 | N==1
    y=std(x(find(isnan(x)==0)));

elseif M>1 & N>1
    for i=1:N
      if ~isnan(x(:,i))
        y(i)=std(x(find(isnan(x(:,i))==0),i));
      else
        y(i)=NaN;
      end
    end
end
