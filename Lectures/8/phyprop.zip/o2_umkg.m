  function O2=o2_Umkg(s,t,p,ox)
%  convert Oxygen from ml/l to Umol/kg or reverse
% convert Oxygen from  ml/l to Umol/kg depending on magnitude of oxygen input
%  if max. input Oxygen less than 20 then assumes convert of ml/l to Um/kg!!!!
%  calc. density anamoly using sg=1.0+(sw_pden(s,th,p,0.0)-1000)/1000.
% from Phil Morgan
%  function O2=o2_Umkg(s,t,p,ox)

ox_cal=44.66;
%  compute density in kg/cm3
 sg=1.0+(sw_pden(s,t,p,0.0)-1000)/1000.;
% find max. o2
 ox_max=mmax(ox);

  if(ox_max<=20)
  O2=ox_cal*ox./sg;

  else
  O2=ox.*sg/ox_cal;
  end
 return
end
