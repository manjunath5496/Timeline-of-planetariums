
// Class Name: coord
//
class coord{
 public:
   coord(){};
   coord( int, int, int);
  ~coord(){};
   coord operator=(coord);
   coord operator+(coord );
   void print();
 private:
   int cx;
   int cy;
   int cz;
};

coord coord::operator= (coord c2)
{
  cx = c2.cx;
  cy = c2.cy;
  cz = c2.cz;
}

coord coord::operator+ (coord c2)
{
  coord temp;
  temp.cx = cx + c2.cx;
  temp.cy = cy + c2.cy;
  temp.cz = cz + c2.cz;
  return(temp);
}

coord::coord(int ix, int iy, int iz){
  cx = ix;
  cy = iy;
  cz = iz;
}

void coord::print(){
  cout << "(" << cx;
  cout << "," << cy;
  cout << "," << cz << ")\n";
}
