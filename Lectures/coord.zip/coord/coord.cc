#include <iostream.h>
#include "coord.h"

main() {
 coord p1(1,1,1);
 coord p2(1,1,1);
 coord p3;

 p3 = p1 + p2;

 p3.print();
}
