/* ===== Class interface definition ===== */
class String {
 public: 
  String();                   /* Constructor           */
  ~String();                  /* Destructor            */
  void set(char *s);          /* Set a string          */
  char *s();                  /* Get string value      */
 protected:
  char *str;                  /* Pointer to the string */
  int  lngth;                 /* Length of the string  */
};

/* ===== Class Methods ===== */
/* Constructor */
String::String() {
 str = 0;
 set("");
 printf("I created a string\n");
}

/* Destructor */
String::~String() {
 delete[] str;
 printf("I deleted a string\n");
}

/* Set str to point to a priveate copy of s */
void String::set(char *s) {
 delete[] str;
 lngth  = strlen(s);
 str    = new char[lngth+1];
 strcpy(str, s);
}

/* Return the pointer to the string  */
char *String::s()  {
 printf("In method s\n");
 return str;
}
