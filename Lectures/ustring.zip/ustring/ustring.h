/* Extend string class to uString       */
/* uString stores strings as upper case */
class uString : public String {
 public:
  void set( char *);    /* Set a uString */
};
/* Set str to point to a private copy of s */
void uString::set(char *s) {
 int i;
 String::set(s);
 for (i=0;i<strlen(s);++i) {
  if ( str[i] >= 'a' && str[i] <= 'z' ) {
   str[i] = toupper(str[i]);
  }
 }
}
