#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "string.h"
#include "ustring.h"

main()
{
 String  s1;
 uString s2;

 printf("Executable code starting\n");

 s1.set("Hello");
 printf("%s\n",s1.s());
 s2.set("Hello");
 printf("%s\n",s2.s());

 printf("Executable code ending\n");
}
